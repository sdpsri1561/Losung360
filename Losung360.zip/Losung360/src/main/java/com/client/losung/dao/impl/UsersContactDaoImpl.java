package com.client.losung.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import com.client.losung.constants.AppConstants;
import com.client.losung.dao.UsersContactDao;
import com.client.losung.entity.UserEntity;
import com.client.losung.exception.EntityNotFoundException;
import com.client.losung.repository.UsersContactRepository;

@Component
public class UsersContactDaoImpl implements UsersContactDao {

	@Autowired
	private UsersContactRepository usersContactRepository;

	@Override
	public UserEntity saveUserEntity(UserEntity userEntity) {
		return usersContactRepository.save(userEntity);
	}

	@Override
	public UserEntity findUserEntityById(Long id) {
		return usersContactRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException(AppConstants.ErrorTypes.ENTITY_NOT_EXIST,
						AppConstants.ErrorCodes.ENTITY_NOT_EXIST_ERROR_CODE,
						AppConstants.ErrorMessages.ENTITY_NOT_EXIST_ERROR_MESSAGE));
	}

	@Override
	public Page<UserEntity> allUsersContactDetailsPagesInAscendingOrderOfIdByDefaultValues(Pageable pageableRequest) {
		return usersContactRepository.allUsersContactDetailsPagesInAscendingOrderOfIdByDefaultValues(pageableRequest);
	}

	@Override
	public Page<UserEntity> getAllUsersContactDetailsByFirstNameAndByLastNameAndEmail(Pageable pageableRequest,
			String firstName, String lastName, String email) {
		return usersContactRepository.getAllUsersContactDetailsByFirstNameAndByLastNameAndEmail(pageableRequest,
				firstName, lastName, email);
	}

	@Override
	public Page<UserEntity> getAllUsersContactDetailsByAnyTwoOutOfFirstNameAndByLastNameAndEmail(
			Pageable pageableRequest, String firstName, String lastName, String email) {
		return usersContactRepository.getAllUsersContactDetailsByAnyTwoOutOfFirstNameAndByLastNameAndEmail(
				pageableRequest, firstName, lastName, email);
	}

	@Override
	public Page<UserEntity> getAllUsersContactDetailsByFirstNameOrByLastNameOrEmail(Pageable pageableRequest,
			String firstName, String lastName, String email) {
		return usersContactRepository.getAllUsersContactDetailsByFirstNameOrByLastNameOrEmail(pageableRequest,
				firstName, lastName, email);
	}

	@Override
	public boolean deleteAnyUserDetailsById(UserEntity userEntity) {
		usersContactRepository.delete(userEntity);
		return true;
	}
}
