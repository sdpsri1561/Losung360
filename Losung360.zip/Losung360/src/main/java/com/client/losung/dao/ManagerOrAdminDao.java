package com.client.losung.dao;

import org.springframework.stereotype.Repository;

import com.client.losung.entity.ManagerOrAdminEntity;

@Repository
public interface ManagerOrAdminDao {

	ManagerOrAdminEntity getManagerOrAdminEntity(String userName);

	void saveEmployerEntity(ManagerOrAdminEntity managerOrAdminEntity);

	ManagerOrAdminEntity findByEmailAndPassword(String email, String encryptedpassword);

}
