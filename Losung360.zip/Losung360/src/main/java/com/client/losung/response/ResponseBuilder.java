package com.client.losung.response;

import com.client.losung.constants.AppConstants;
import com.client.losung.exception.AppException;

public class ResponseBuilder {

	public static BaseApiResponse getSuccessResponse(Object responseData) throws AppException {
		
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstants.StatusCodes.SUCCESS));
		baseApiResponse.setResponseData(responseData);
		
		return baseApiResponse;
	}
	
	public static BaseApiResponse getSuccessResponse() throws AppException {
		
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstants.StatusCodes.SUCCESS));
		baseApiResponse.setResponseData(null);
		
		return baseApiResponse;
	}
}
