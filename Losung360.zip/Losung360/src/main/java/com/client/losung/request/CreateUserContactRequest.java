package com.client.losung.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateUserContactRequest {
	
	@NotBlank(message = "First Name cannot be null or blank.")
	@NotNull(message = "First Name cannot be null or blank.")
	private String firstName;
	
	@NotBlank(message = "Last Name cannot be null or blank.")
	@NotNull(message = "Last Name cannot be null or blank.")
	private String lastName;
	
	@NotBlank(message = "Phone Country Code cannot be null or blank.")
	@NotNull(message = "Phone Country Code cannot be null or blank.")
	private String phoneCountryCode;
	
	@NotBlank(message = "Phone Number cannot be null or blank.")
	@NotNull(message = "Phone Name cannot be null or blank.")
	private String phoneNumber;
	
	@NotBlank(message = "Email cannot be null or blank.")
	@NotNull(message = "Email cannot be null or blank.")
	private String email;
	
}
