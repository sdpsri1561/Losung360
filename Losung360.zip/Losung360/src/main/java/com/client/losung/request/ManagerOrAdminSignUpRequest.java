package com.client.losung.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ManagerOrAdminSignUpRequest {

	@NotBlank(message = "Enter an Email ID")
	@Email(message = "Enter a valid Email ID")
	private String email;
	
	@NotBlank(message = "Enter full name")
    @Pattern(regexp = "^[A-Za-z\\s]*$",message = "Name should only contains letters")
	private String fullName;
	
	@NotBlank(message = "Enter a password")
	@Length(max = 15, min = 8, message = "Password should be minimum 8 characters long or maximum 15 characters long"  )
	private String password;
}
