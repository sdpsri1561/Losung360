package com.client.losung.service;

import com.client.losung.entity.RoleEntity;

public interface CommonService {

	RoleEntity getRoleByName(String roleName);

}
