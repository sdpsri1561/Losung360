package com.client.losung.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ManagerOrAdminSignInResponse {
	String sighInMessage;
}
