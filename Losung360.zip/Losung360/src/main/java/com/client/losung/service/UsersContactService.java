package com.client.losung.service;

import com.client.losung.bo.CreateUserContactRequestBo;
import com.client.losung.bo.GetAllUsersContactDetailsBo;
import com.client.losung.bo.UpdateUserContactRequestBo;
import com.client.losung.response.AllUsersContactDetailsResponse;
import com.client.losung.response.CreateUserContactResponse;
import com.client.losung.response.DeleteUserDetailsResponse;
import com.client.losung.response.UpdateUserContactResponse;

public interface UsersContactService {

	CreateUserContactResponse createUserContact(CreateUserContactRequestBo createUserContactRequestBo);

	UpdateUserContactResponse upeateCreatedUserContact(UpdateUserContactRequestBo updateUserContactRequestBo);

	AllUsersContactDetailsResponse getAllUsersContactDetailsByFilters(int page,
			int limit, GetAllUsersContactDetailsBo getAllUsersContactDetailsBo);

	DeleteUserDetailsResponse deleteAnyUserDetails(Long id);

}
