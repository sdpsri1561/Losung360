package com.client.losung.bo;

import lombok.Setter;
import lombok.ToString;
import lombok.Getter;

@Getter
@Setter
@ToString
public class GetAllUsersContactDetailsBo {
	
	private String firstName;
	private String lastName;
	private String email;

}
