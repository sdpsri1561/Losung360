package com.client.losung.constants;

public interface AppConstants {
	
	public interface Commons {
		String PAGE_NUMBER = "page";
		String PAGE_DEFAULT_VALUE = "0";
		String PAGE_LIMIT = "limit";
		String PAGE_LIMIT_VALUE = "10";
		String FIRST_NAME = "firstName";
		String LAST_NAME = "lastName";
		String EMAIL = "email";
		String TOKEN_HEADER = "Authorization";
		String ROLE_TYPE = "Role Name";
		String LOGIN_REQUEST_MESSAGE_THERE_IS_NO_SUCH_ACCOUNT = "There is no such account. Please enter a correct email Id or create your account, if didn't create.";
		String LOGIN_REQUEST_MESSAGE_PASSWORD_INCORRECT = "Account is already there but Password is not correct.";
		String LOGIN_REQUEST_MESSAGE = "Login Successfully. Now, You can start your activity.";
		String CREATE_ACCOUNT_SUCCESSFULLY_MESSAGE = " Your Account Created Succesfully. Now You can log in and can start you activity.";
		String HI_MESSAGE = "Hello ";
		String DELETE_MESSAGE = "User's Contact Details deleted Successfully.";
	}

	public interface StatusCodes {
		int SUCCESS = 0;
		int FAILURE = 1;
	}

	public interface ErrorTypes {
		String SIGN_UP_ERROR = "Signup Error";
		String ENTITY_NOT_EXIST = "Entity Not Exist Error";
		String EMAIL_CAN_NOT_UPDATE_ERROR_TYPE = "Email can not update error type";
		String NULL_ENTITY = "Entity not present error";
	}

	public interface ErrorCodes {
		String ADMIN_OR_MANAGER_ALREADY_EXISTS_ERROR_CODE = "101";
		String ENTITY_NOT_EXIST_ERROR_CODE = "102";
		String EMAIL_CAN_NOT_UPDATE_ERROR_CODE = "103";
		String ROLE_ENTITY_NOT_PRESENT_ERROR_CODE = "104";
	}

	public interface ErrorMessages {
		String ADMIN_OR_MANAGER_ALREADY_EXISTS_ERROR_MESSAGE = "Admin Or User already registered. Try with  different Email ID.";
		String ENTITY_NOT_EXIST_ERROR_MESSAGE = "There is no such Entity";
		String EMAIL_CAN_NOT_UPDATE_ERROR_MESSAGE = "Email can not be null, can not be blank, even can not be updated, and must have to give.";
		String ROLE_ENTITY_NOT_PRESENT_ERROR_MESSAGE = "Entity not found : Role Entity";
	}

	public interface RoleName {
		String ROLE_ADMIN = "ADMIN";
		String ROLE_MANAGER = "MANAGER";
	}

	
}
