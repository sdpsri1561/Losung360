package com.client.losung.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateUserContactResponse {
	private Long id;
	private String firstName;
	private String lastName;
	private String phoneCountryCode;
	private String phoneNumber;
	private String email;
}
