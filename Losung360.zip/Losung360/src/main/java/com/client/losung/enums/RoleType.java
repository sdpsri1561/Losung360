package com.client.losung.enums;

public enum RoleType {

	ADMIN, MANAGER
}
