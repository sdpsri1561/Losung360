package com.client.losung.dao;

import org.springframework.stereotype.Repository;

import com.client.losung.entity.RoleEntity;

@Repository
public interface CommonDao {

	RoleEntity getRoleByName(String roleType);

}
