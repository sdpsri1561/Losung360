package com.client.losung.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.client.losung.constants.AppConstants;
import com.client.losung.dao.CommonDao;
import com.client.losung.entity.RoleEntity;
import com.client.losung.exception.EntityNotFoundException;
import com.client.losung.repository.RoleRepository;

@Component
public class CommonDaoImpl implements CommonDao {
	
	@Autowired
	private RoleRepository roleRepository;

	@Override
	public RoleEntity getRoleByName(String roleType) {
		return roleRepository.findByRole(roleType)
				.orElseThrow(() -> new EntityNotFoundException(AppConstants.ErrorTypes.NULL_ENTITY,
						AppConstants.ErrorCodes.ROLE_ENTITY_NOT_PRESENT_ERROR_CODE,
						AppConstants.ErrorMessages.ROLE_ENTITY_NOT_PRESENT_ERROR_MESSAGE));
	}

}
