package com.client.losung.bo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ManagerOrAdminSignInRequestBo {

	private String fullName;
	private String email;
	private String password;
}
