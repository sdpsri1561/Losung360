package com.client.losung.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.client.losung.bo.ManagerOrAdminSignInRequestBo;
import com.client.losung.bo.ManagerOrAdminSignUpRequestBo;
import com.client.losung.constants.AppConstants;
import com.client.losung.constants.RestMappingConstants;
import com.client.losung.convertor.ManagerOrAdminConvertor;
import com.client.losung.enums.RoleType;
import com.client.losung.request.ManagerOrAdminSignInRequest;
import com.client.losung.request.ManagerOrAdminSignUpRequest;
import com.client.losung.response.AccountCreatedSuccessfullyResponse;
import com.client.losung.response.BaseApiResponse;
import com.client.losung.response.ManagerOrAdminSignInResponse;
import com.client.losung.response.ResponseBuilder;
import com.client.losung.service.CommonService;
import com.client.losung.service.ManagerOrAdminService;

@RestController
@RequestMapping(value = RestMappingConstants.ManagerOrAdminRequestUri.MANAGER_OR_ADMIN_BASE_URI)
public class ManagerOrAdminController {

	@Autowired
	private ManagerOrAdminService managerOrAdminService;

	@Autowired
	CommonService commonService;

	/**
	 * @author Sandeep Srivastava
	 * @apiNote This is the api which will be used to create the account either by
	 *          Manager or Admin
	 * @param managerOrAdminSignUpRequest
	 * @param roleType
	 * @param Autherization-token
	 * @return a success response
	 */
	/* Sign up */
	/**************************************************************************************************/
	@PostMapping(path = RestMappingConstants.ManagerOrAdminRequestUri.SIGNUP)
	public ResponseEntity<BaseApiResponse> addManagerOrAdmin(
			@Valid @RequestBody ManagerOrAdminSignUpRequest managerOrAdminSignUpRequest,
			@RequestParam(value = AppConstants.Commons.ROLE_TYPE) RoleType roleType,
			@RequestHeader(value = AppConstants.Commons.TOKEN_HEADER, required = false) String token) {

		ManagerOrAdminSignUpRequestBo signUpBo = ManagerOrAdminConvertor
				.convertManagerOrAdminRequestToBo(managerOrAdminSignUpRequest);
		AccountCreatedSuccessfullyResponse accountCreatedSuccessfullyResponse = managerOrAdminService
				.addmanagerOrAdmin(signUpBo, roleType);
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(accountCreatedSuccessfullyResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.CREATED);
	}

	/**
	 * @author Sandeep Srivastava
	 * @apiNote This is the api which will be used to log in by Manager or Admin
	 * @param Autherization-token
	 * @return signInResponse an object of ManagerOrAdminSignInResponse.java
	 */
	/* Sign in */
	/**************************************************************************************************/
	@PostMapping(path = RestMappingConstants.ManagerOrAdminRequestUri.SIGNIN)
	public ResponseEntity<BaseApiResponse> sighIn(
			@Valid @RequestBody ManagerOrAdminSignInRequest managerOrAdminSignInRequest,
			@RequestHeader(value = AppConstants.Commons.TOKEN_HEADER, required = false) String token) {

		ManagerOrAdminSignInRequestBo signInBo = ManagerOrAdminConvertor
				.convertManagerOrAdminLogInRequestToBo(managerOrAdminSignInRequest);

		ManagerOrAdminSignInResponse signInResponse = managerOrAdminService.sighIn(signInBo);
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(signInResponse);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.CREATED);
	}

}
