package com.client.losung.service.impl;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.client.losung.bo.ManagerOrAdminSignInRequestBo;
import com.client.losung.bo.ManagerOrAdminSignUpRequestBo;
import com.client.losung.constants.AppConstants;
import com.client.losung.convertor.ManagerOrAdminConvertor;
import com.client.losung.dao.ManagerOrAdminDao;
import com.client.losung.entity.ManagerOrAdminEntity;
import com.client.losung.entity.RoleEntity;
import com.client.losung.enums.RoleType;
import com.client.losung.exception.UserAlreadyExistException;
import com.client.losung.response.AccountCreatedSuccessfullyResponse;
import com.client.losung.response.ManagerOrAdminSignInResponse;
import com.client.losung.service.CommonService;
import com.client.losung.service.ManagerOrAdminService;

@Service
public class ManagerOrAdminServiceImpl implements ManagerOrAdminService {

	@Autowired
	private ManagerOrAdminDao managerOrAdminDao;

	@Autowired
	private CommonService commonService;

	@Override
	public AccountCreatedSuccessfullyResponse addmanagerOrAdmin(ManagerOrAdminSignUpRequestBo signUpBo, RoleType roleType) {

		if (!isExistingManagerOrAdmin(signUpBo.getEmail())) // check if entered Admin Or Manager already exists
		{
			RoleEntity roleEntity = null;

			if (true) {
				roleEntity = commonService.getRoleByName(roleType.toString());
			}

			ManagerOrAdminEntity managerOrAdminEntity = ManagerOrAdminConvertor.convertBoToEntity(signUpBo);

			String encryptedpassword = null;

			try {
				/* MessageDigest instance for MD5. */
				MessageDigest m = MessageDigest.getInstance("MD5");

				/* Add plain-text password bytes to digest using MD5 update() method. */
				m.update(signUpBo.getPassword().getBytes());

				/* Convert the hash value into bytes */
				byte[] bytes = m.digest();

				/*
				 * The bytes array has bytes in decimal form. Converting it into hexadecimal
				 * format.
				 */
				StringBuilder s = new StringBuilder();
				for (int i = 0; i < bytes.length; i++) {
					s.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
				}

				/* Complete hashed password in hexadecimal format */
				encryptedpassword = s.toString();
				managerOrAdminEntity.setPassword(encryptedpassword);
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}

			/** Setting role of the user */
			List<RoleEntity> roleEntityList = new ArrayList<>();
			roleEntityList.add(roleEntity);
			managerOrAdminEntity.setRoleList(roleEntityList);

			managerOrAdminDao.saveEmployerEntity(managerOrAdminEntity);

		} else {
			throw new UserAlreadyExistException(AppConstants.ErrorTypes.SIGN_UP_ERROR,
					AppConstants.ErrorCodes.ADMIN_OR_MANAGER_ALREADY_EXISTS_ERROR_CODE,
					AppConstants.ErrorMessages.ADMIN_OR_MANAGER_ALREADY_EXISTS_ERROR_MESSAGE);
		}
		
		AccountCreatedSuccessfullyResponse response = new AccountCreatedSuccessfullyResponse();
		response.setSuccessMessage(AppConstants.Commons.HI_MESSAGE+ signUpBo.getFullName()+","+AppConstants.Commons.CREATE_ACCOUNT_SUCCESSFULLY_MESSAGE);
		return response;
	}

	public boolean isExistingManagerOrAdmin(String email) {

		ManagerOrAdminEntity managerOrAdminEntity = managerOrAdminDao.getManagerOrAdminEntity(email);

		if (managerOrAdminEntity == null)
			return false;
		return true;
	}

	@Override
	public ManagerOrAdminSignInResponse sighIn(ManagerOrAdminSignInRequestBo signInBo) {

		String encryptedpassword = null;

		try {
			/* MessageDigest instance for MD5. */
			MessageDigest m = MessageDigest.getInstance("MD5");

			/* Add plain-text password bytes to digest using MD5 update() method. */
			m.update(signInBo.getPassword().getBytes());

			/* Convert the hash value into bytes */
			byte[] bytes = m.digest();

			/*
			 * The bytes array has bytes in decimal form. Converting it into hexadecimal
			 * format.
			 */
			StringBuilder s = new StringBuilder();
			for (int i = 0; i < bytes.length; i++) {
				s.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
			}

			/* Complete hashed password in hexadecimal format */
			encryptedpassword = s.toString();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		ManagerOrAdminSignInResponse managerOrAdminSignInResponse = new ManagerOrAdminSignInResponse();

		ManagerOrAdminEntity managerOrAdminEntity = managerOrAdminDao.findByEmailAndPassword(signInBo.getEmail(),
				encryptedpassword);
		ManagerOrAdminEntity foundManagerOrAdminEntityByEmail = managerOrAdminDao
				.getManagerOrAdminEntity(signInBo.getEmail());
		if (managerOrAdminEntity == null && foundManagerOrAdminEntityByEmail == null) {
			managerOrAdminSignInResponse
					.setSighInMessage(AppConstants.Commons.LOGIN_REQUEST_MESSAGE_THERE_IS_NO_SUCH_ACCOUNT);
			return managerOrAdminSignInResponse;
		}
		if (managerOrAdminEntity == null && foundManagerOrAdminEntityByEmail != null) {
			managerOrAdminSignInResponse
					.setSighInMessage(AppConstants.Commons.LOGIN_REQUEST_MESSAGE_PASSWORD_INCORRECT);
			return managerOrAdminSignInResponse;
		}

		managerOrAdminSignInResponse.setSighInMessage(AppConstants.Commons.LOGIN_REQUEST_MESSAGE);
		return managerOrAdminSignInResponse;
	}

}
