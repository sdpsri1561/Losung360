package com.client.losung.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.client.losung.dao.ManagerOrAdminDao;
import com.client.losung.entity.ManagerOrAdminEntity;
import com.client.losung.repository.ManagerOrAdminEntityRepository;

@Component
public class ManagerOrAdminDaoImpl implements ManagerOrAdminDao{
	
	@Autowired
	private ManagerOrAdminEntityRepository managerOrAdminEntityRepository;
	
	/* Get ManagerOrAdminEntity By Email */
	/**************************************************************************************************/
	@Override
	public ManagerOrAdminEntity getManagerOrAdminEntity(String email) {

		return managerOrAdminEntityRepository.findByEmail(email);
	}

	/* Save ManagerOrAdminEntity */
	/**************************************************************************************************/
	@Override
	public void saveEmployerEntity(ManagerOrAdminEntity managerOrAdminEntity) {
		 managerOrAdminEntityRepository.save(managerOrAdminEntity);
	}

	@Override
	public ManagerOrAdminEntity findByEmailAndPassword(String email, String encryptedpassword) {
		 
		return managerOrAdminEntityRepository.findByEmailAndPassword(email, encryptedpassword);
	}

}
