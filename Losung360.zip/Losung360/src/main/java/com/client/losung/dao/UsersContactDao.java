package com.client.losung.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.client.losung.entity.UserEntity;

public interface UsersContactDao {

	UserEntity saveUserEntity(UserEntity user);

	UserEntity findUserEntityById(Long id);

	Page<UserEntity> allUsersContactDetailsPagesInAscendingOrderOfIdByDefaultValues(Pageable pageableRequest);

	Page<UserEntity> getAllUsersContactDetailsByFirstNameAndByLastNameAndEmail(Pageable pageableRequest,
			String firstName, String lastName, String email);

	Page<UserEntity> getAllUsersContactDetailsByAnyTwoOutOfFirstNameAndByLastNameAndEmail(Pageable pageableRequest,
			String firstName, String lastName, String email);

	Page<UserEntity> getAllUsersContactDetailsByFirstNameOrByLastNameOrEmail(Pageable pageableRequest, String firstName,
			String lastName, String email);

	boolean deleteAnyUserDetailsById(UserEntity userEntity);
}
