package com.client.losung.request;

import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateUserContactRequest {

	@NotNull(message = "Id cannot be null or zero.")
	private Long id;
	
	private String firstName;
	
	private String lastName;
	
	private String phoneCountryCode;
	
	private String phoneNumber;
	
	private String email;
}
