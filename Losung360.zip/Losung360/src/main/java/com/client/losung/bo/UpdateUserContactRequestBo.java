package com.client.losung.bo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateUserContactRequestBo {
	private Long id;
	private String firstName;
	private String lastName;
	private String phoneCountryCode;
	private String phoneNumber;
	private String email;
}
