package com.client.losung.convertor;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;

import com.client.losung.bo.CreateUserContactRequestBo;
import com.client.losung.bo.GetAllUsersContactDetailsBo;
import com.client.losung.bo.UpdateUserContactRequestBo;
import com.client.losung.request.CreateUserContactRequest;
import com.client.losung.request.UpdateUserContactRequest;

public class UsersContactConvertor {

	public static CreateUserContactRequestBo prepareCreateUserBo(
			@Valid CreateUserContactRequest createUserContactRequest) {

		CreateUserContactRequestBo createUserRequestBo = new CreateUserContactRequestBo();
		BeanUtils.copyProperties(createUserContactRequest, createUserRequestBo);
		return createUserRequestBo;

	}

	public static UpdateUserContactRequestBo prepareupdateUserContactBo(
			@Valid UpdateUserContactRequest updateUserContactRequest) {
		UpdateUserContactRequestBo updateUserContactRequestBo = new UpdateUserContactRequestBo();
		BeanUtils.copyProperties(updateUserContactRequest, updateUserContactRequestBo);
		return updateUserContactRequestBo;
	}

	public static GetAllUsersContactDetailsBo prepareGetAllUsersContactDetailsBo(String firstName, String lastName,
			String email) {
		GetAllUsersContactDetailsBo getAllUsersContactDetailsBo = new GetAllUsersContactDetailsBo();
		getAllUsersContactDetailsBo.setFirstName(firstName);
		getAllUsersContactDetailsBo.setLastName(lastName);
		getAllUsersContactDetailsBo.setEmail(email);
		return getAllUsersContactDetailsBo;
	}

}
