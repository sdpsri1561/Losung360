package com.client.losung.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AllUsersContactDetailsPojo {
	private Long id;
	private String firstName;
	private String lastName;
	private String phoneCountryCode;
	private String phoneNumber;
	private String email;
}
