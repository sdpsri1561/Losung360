package com.client.losung.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.client.losung.entity.UserEntity;

@Repository
public interface UsersContactRepository extends JpaRepository<UserEntity, Long> {

	@Query(value = "SELECT * FROM losung360_users AS u ORDER BY u.id ASC", nativeQuery = true)
	Page<UserEntity> allUsersContactDetailsPagesInAscendingOrderOfIdByDefaultValues(Pageable pageableRequest);

	@Query(value = "SELECT * FROM losung360_users AS u WHERE u.first_name=:firstName AND u.last_name=:lastName AND u.email_id=:email ORDER BY u.id ASC", nativeQuery = true)
	Page<UserEntity> getAllUsersContactDetailsByFirstNameAndByLastNameAndEmail(Pageable pageableRequest,
			String firstName, String lastName, String email);

	@Query(value = "SELECT * FROM losung360_users AS u WHERE (u.first_name=:firstName AND u.last_name=:lastName) "
			+ "OR (u.last_name=:lastName AND u.email_id=:email) "
			+ "OR (u.first_name=:firstName AND u.email_id=:email) " + "ORDER BY u.id ASC", nativeQuery = true)
	Page<UserEntity> getAllUsersContactDetailsByAnyTwoOutOfFirstNameAndByLastNameAndEmail(Pageable pageableRequest,
			String firstName, String lastName, String email);

	@Query(value = "SELECT * FROM losung360_users AS u WHERE u.first_name=:firstName OR u.last_name=:lastName OR u.email_id=:email ORDER BY u.id ASC", nativeQuery = true)
	Page<UserEntity> getAllUsersContactDetailsByFirstNameOrByLastNameOrEmail(Pageable pageableRequest, String firstName,
			String lastName, String email);

}
