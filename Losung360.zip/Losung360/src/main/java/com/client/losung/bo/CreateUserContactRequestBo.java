package com.client.losung.bo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateUserContactRequestBo {

	private String firstName;

	private String lastName;

	private String phoneCountryCode;
	
	private String phoneNumber;
	
	private String email;
	
}
