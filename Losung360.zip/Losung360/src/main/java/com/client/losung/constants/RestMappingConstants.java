package com.client.losung.constants;

public interface RestMappingConstants {
	
	String APP_BASE = "/v1/api";
	
	interface UsersContactUri{
		String USERS_CONTACT_BASE_URI=APP_BASE+"/users/contact";
		String CREATE_USERS_CONTACT="/createUserContact";
		String UPDATE_USER_CONTACT="/updateUserContact";	
		String  GET_ALL_USERS_CONTACT_DETAILS_BY_FILTERS = "getAllUsersContactDetailsByFilters";
		String  DELETE_ANY_USER_DETAILS = "deleteAnyUserDetails";
	}
	
	interface ManagerOrAdminRequestUri{
		String MANAGER_OR_ADMIN_BASE_URI=APP_BASE+"/managerOrAdmin";
		String SIGNUP = "/sighUp";
		String SIGNIN = "/signIn";
	}
}
