package com.client.losung.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.client.losung.dao.CommonDao;
import com.client.losung.entity.RoleEntity;
import com.client.losung.service.CommonService;

@Service
public class CommonServiceImpl implements CommonService {
	
	@Autowired
	private CommonDao commonDao;
	
	@Override
	public RoleEntity getRoleByName(String roleType) {
		return commonDao.getRoleByName(roleType);
	}

}
