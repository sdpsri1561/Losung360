package com.client.losung.response;

import java.util.List;

import com.client.losung.entity.UserEntity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AllUsersContactDetailsResponse {
	
	private List<UserEntity> userEntities;
	private CommonPaginationResponse commonPaginationResponse;

}
