package com.client.losung.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.client.losung.entity.ManagerOrAdminEntity;

@Repository
public interface ManagerOrAdminEntityRepository extends JpaRepository<ManagerOrAdminEntity, Long> {

	@Query(value = "Select * From manager_or_admin_entity as moae WHERE moae.email_id=:email", nativeQuery = true)
	ManagerOrAdminEntity findByEmail(String email);

	@Query(value = "Select * From manager_or_admin_entity as moae WHERE moae.email_id=:email AND moae.password=:encryptedpassword", nativeQuery = true)
	ManagerOrAdminEntity findByEmailAndPassword(String email, String encryptedpassword);

}
