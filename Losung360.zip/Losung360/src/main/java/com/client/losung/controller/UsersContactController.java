package com.client.losung.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.client.losung.bo.CreateUserContactRequestBo;
import com.client.losung.bo.GetAllUsersContactDetailsBo;
import com.client.losung.bo.UpdateUserContactRequestBo;
import com.client.losung.constants.AppConstants;
import com.client.losung.constants.RestMappingConstants;
import com.client.losung.convertor.UsersContactConvertor;
import com.client.losung.request.CreateUserContactRequest;
import com.client.losung.request.UpdateUserContactRequest;
import com.client.losung.response.AllUsersContactDetailsResponse;
import com.client.losung.response.BaseApiResponse;
import com.client.losung.response.CreateUserContactResponse;
import com.client.losung.response.DeleteUserDetailsResponse;
import com.client.losung.response.ResponseBuilder;
import com.client.losung.response.UpdateUserContactResponse;
import com.client.losung.service.UsersContactService;

@RestController
@RequestMapping(value = RestMappingConstants.UsersContactUri.USERS_CONTACT_BASE_URI)
public class UsersContactController {

	@Autowired
	private UsersContactService usersContactService;

	/**
	 * @author Sandeep Srivastava
	 * @apiNote This is the api which will be used to create user
	 * @TimeComplexity Practical = (83+7+5+5+5+75+76+79+7+6)/10 =34.8 milliseconds
	 * @param createUserContactRequest
	 * @param Autherization-token
	 * @return an Object Of CreateUserContactResponse.java
	 */
	/* CREATE USERS CONTACT */
	/**************************************************************************************************/
	@PostMapping(path = RestMappingConstants.UsersContactUri.CREATE_USERS_CONTACT)
	public ResponseEntity<BaseApiResponse> createUserContact(
			@Valid @RequestBody CreateUserContactRequest createUserContactRequest,
			@RequestHeader(value = AppConstants.Commons.TOKEN_HEADER, required = false) String token) {
		long startTime = System.currentTimeMillis();
		CreateUserContactRequestBo createUserContactRequestBo = UsersContactConvertor
				.prepareCreateUserBo(createUserContactRequest);
		CreateUserContactResponse createUserContactResponse = usersContactService
				.createUserContact(createUserContactRequestBo);
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(createUserContactResponse);
		System.out.println("Total Time taken by Algorithm: " + (System.currentTimeMillis() - startTime) + "ms");
		return new ResponseEntity<>(baseApiResponse, HttpStatus.CREATED);
	}

	/**
	 * @author Sandeep Srivastava
	 * @apiNote This is the api which will be used to update user
	 * @TimeComplexity Practical =(104+61+76+83+88+48+103+88+62+73)/10 = 78.6 milliseconds
	 * @param updateUserContactRequest
	 * @param Autherization-token
	 * @return an Object Of UpdateUserContactResponse.java
	 */
	/* UPDATE USER CONTACT */
	/**************************************************************************************************/
	@PutMapping(path = RestMappingConstants.UsersContactUri.UPDATE_USER_CONTACT)
	public ResponseEntity<BaseApiResponse> upeateCreatedUserContact(
			@Valid @RequestBody UpdateUserContactRequest updateUserContactRequest,
			@RequestHeader(value = AppConstants.Commons.TOKEN_HEADER, required = false) String token) {
		long startTime = System.currentTimeMillis();
		UpdateUserContactRequestBo updateUserContactRequestBo = UsersContactConvertor
				.prepareupdateUserContactBo(updateUserContactRequest);
		UpdateUserContactResponse updateUserContactResponse = usersContactService
				.upeateCreatedUserContact(updateUserContactRequestBo);
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(updateUserContactResponse);
		System.out.println("Total Time taken by Algorithm: " + (System.currentTimeMillis() - startTime) + "ms");
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	/**
	 * @author Sandeep Srivastava
	 * @apiNote This is the api which will be used to get the users based on filters
	 *          either by any one of three(i.e. firstName, lastName and email) OR
	 *          any two out of three OR by giving all OR by default
	 * @TimeComplexity
	 * (1) Practical[When we filter by any one out of three] = (64+84+54+83+87)/5 = 74.4 milliseconds,
	 * (2) Practical[When we filter by any two out of three] = (53+72+56+67+71)/5 = 63.8 milliseconds,
	 * (3) Practical[When we filter by all three] = (56+92+69+79+51)/5 = 69.4 milliseconds,
	 * (4) Practical[By Default] = (110+6+60+58+95+53+78+61+58+56)/10 = 63.5 milliseconds
	 * 
	 * @param firstName
	 * @param lastName
	 * @param email
	 * @param page
	 * @param limit
	 * @param Autherization-token
	 * @return an Object Of AllUsersContactDetailsResponse.java class
	 */
	/* GET ALL USERS CONTACT DETAILS BY FILTERS */
	/**************************************************************************************************/
	@GetMapping(path = RestMappingConstants.UsersContactUri.GET_ALL_USERS_CONTACT_DETAILS_BY_FILTERS)
	public ResponseEntity<BaseApiResponse> getAllUsersContactDetailsByFilters(
			@RequestParam(value = AppConstants.Commons.FIRST_NAME, required = false) String firstName,
			@RequestParam(value = AppConstants.Commons.LAST_NAME, required = false) String lastName,
			@RequestParam(value = AppConstants.Commons.EMAIL, required = false) String email,
			@RequestParam(value = AppConstants.Commons.PAGE_NUMBER, defaultValue = AppConstants.Commons.PAGE_DEFAULT_VALUE) int page,
			@RequestParam(value = AppConstants.Commons.PAGE_LIMIT, defaultValue = AppConstants.Commons.PAGE_LIMIT_VALUE) int limit,
			@RequestHeader(value = AppConstants.Commons.TOKEN_HEADER, required = false) String token) {
		long startTime = System.currentTimeMillis();
		GetAllUsersContactDetailsBo getAllUsersContactDetailsBo = UsersContactConvertor
				.prepareGetAllUsersContactDetailsBo(firstName, lastName, email);
		AllUsersContactDetailsResponse allUsersContactDetailsResponse = usersContactService
				.getAllUsersContactDetailsByFilters(page, limit, getAllUsersContactDetailsBo);
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(allUsersContactDetailsResponse);
		System.out.println("Total Time taken by Algorithm: " + (System.currentTimeMillis() - startTime) + "ms");
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}

	/**
	 * @author Sandeep Srivastava
	 * @apiNote This is the api which will be used to delete by primary id
	 * @param id
	 * @TimeComplexity Practical =(110+92+83+11+102)/5 = 76.6  milliseconds
	 * @param Autherization-token
	 * @return delete status
	 */
	/* DELETE ANY USER DETAILS */
	/**************************************************************************************************/
	@DeleteMapping(path = RestMappingConstants.UsersContactUri.DELETE_ANY_USER_DETAILS)
	public ResponseEntity<BaseApiResponse> deleteAnyUserDetails(@RequestParam("id") Long id,
			@RequestHeader(value = AppConstants.Commons.TOKEN_HEADER, required = false) String token) {
		long startTime = System.currentTimeMillis();
		 DeleteUserDetailsResponse response = usersContactService.deleteAnyUserDetails(id);
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(response);
		System.out.println("Total Time taken by Algorithm: " + (System.currentTimeMillis() - startTime) + "ms");
		return new ResponseEntity<>(baseApiResponse, HttpStatus.CREATED);
	}
}
