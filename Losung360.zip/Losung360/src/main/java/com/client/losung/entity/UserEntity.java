package com.client.losung.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "losung360_users")
@Getter
@Setter
public class UserEntity extends BaseEntity {
	
	@Column(name = "first_name")
	private String firstName;
	
	@Column(name = "last_name")
	private String lastName;
	
	@Column(name = "phone_country_code")
	private String phoneCountryCode;
	
	@Column(name = "phone_number")
	private String phoneNumber;
	
	@Column(name = "email_id")
	private String email;
}
