package com.client.losung.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateUserContactResponse {
	private Long id;
	private String firstName;
	private String lastName;
	private String phoneCountryCode;
	private String phoneNumber;
	private String email;
}
