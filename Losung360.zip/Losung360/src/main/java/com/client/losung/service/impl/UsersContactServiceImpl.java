package com.client.losung.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.client.losung.bo.CreateUserContactRequestBo;
import com.client.losung.bo.GetAllUsersContactDetailsBo;
import com.client.losung.bo.UpdateUserContactRequestBo;
import com.client.losung.constants.AppConstants;
import com.client.losung.dao.UsersContactDao;
import com.client.losung.entity.UserEntity;
import com.client.losung.exception.AppException;
import com.client.losung.response.AllUsersContactDetailsResponse;
import com.client.losung.response.CommonPaginationResponse;
import com.client.losung.response.CreateUserContactResponse;
import com.client.losung.response.DeleteUserDetailsResponse;
import com.client.losung.response.UpdateUserContactResponse;
import com.client.losung.service.UsersContactService;

@Service
public class UsersContactServiceImpl implements UsersContactService {
	@Autowired
	private UsersContactDao usersContactDao;

	@Override
	public CreateUserContactResponse createUserContact(CreateUserContactRequestBo createuserEntityContactRequestBo) {
		UserEntity userEntity = new UserEntity();

		/** Prepare an object of UserEntity */
		userEntity.setFirstName(createuserEntityContactRequestBo.getFirstName());
		userEntity.setLastName(createuserEntityContactRequestBo.getLastName());
		userEntity.setPhoneCountryCode(createuserEntityContactRequestBo.getPhoneCountryCode());
		userEntity.setPhoneNumber(createuserEntityContactRequestBo.getPhoneNumber());
		userEntity.setEmail(createuserEntityContactRequestBo.getEmail());

		UserEntity savedUserEntity = usersContactDao.saveUserEntity(userEntity);

		/** create and prepare Object of CreateuserEntityContactResponse */
		CreateUserContactResponse createuserEntityContactResponse = new CreateUserContactResponse();
		createuserEntityContactResponse.setId(savedUserEntity.getId());
		createuserEntityContactResponse.setFirstName(savedUserEntity.getFirstName());
		createuserEntityContactResponse.setLastName(savedUserEntity.getLastName());
		createuserEntityContactResponse.setPhoneCountryCode(savedUserEntity.getPhoneCountryCode());
		createuserEntityContactResponse.setPhoneNumber(savedUserEntity.getPhoneNumber());
		createuserEntityContactResponse.setEmail(savedUserEntity.getEmail());

		/** returning an object of CreateUserContactResponse.java class */
		return createuserEntityContactResponse;
	}

	@Override
	public UpdateUserContactResponse upeateCreatedUserContact(UpdateUserContactRequestBo updateUserRequestBo) {

		/**
		 * Find UserEntity by Id And Throw an Excetion EntityNotFoundException, when
		 * there is no such entity present
		 */
		UserEntity userEntity = usersContactDao.findUserEntityById(updateUserRequestBo.getId());

		/**
		 * Set First Name When NotNull And NotBlank And NotEqual With Stored First Name
		 */
		if (updateUserRequestBo.getFirstName() != null && !updateUserRequestBo.getFirstName().equals("")
				&& !(updateUserRequestBo.getFirstName().equals(userEntity.getFirstName())))
			userEntity.setFirstName(updateUserRequestBo.getFirstName());

		/**
		 * Set Last Name When NotNull And NotBlank And NotEqual With Stored Last Name
		 */
		if (updateUserRequestBo.getLastName() != null && !updateUserRequestBo.getLastName().equals("")
				&& !(updateUserRequestBo.getLastName().equals(userEntity.getLastName())))
			userEntity.setLastName(updateUserRequestBo.getLastName());

		/**
		 * Set Phone Country Code When NotNull And NotBlank And NotEqual With Stored
		 * Phone Country Code
		 */
		if (updateUserRequestBo.getPhoneCountryCode() != null && !updateUserRequestBo.getPhoneCountryCode().equals("")
				&& !(updateUserRequestBo.getPhoneCountryCode().equals(userEntity.getPhoneCountryCode())))
			userEntity.setPhoneCountryCode(updateUserRequestBo.getPhoneCountryCode());

		/**
		 * Set Phone Number When NotNull And NotBlank And NotEqual With Stored Phone
		 * Number
		 */
		if (updateUserRequestBo.getPhoneNumber() != null && !updateUserRequestBo.getPhoneNumber().equals("")
				&& !(updateUserRequestBo.getPhoneNumber().equals(userEntity.getPhoneNumber())))
			userEntity.setPhoneNumber(updateUserRequestBo.getPhoneNumber());

		/**
		 * Throw Exception When NotEqual With Stored Email, because we can not update
		 * email, because during createUserContact email is verified
		 */
		if (!(updateUserRequestBo.getEmail().equals(userEntity.getEmail()))) {
			throw new AppException(AppConstants.ErrorTypes.EMAIL_CAN_NOT_UPDATE_ERROR_TYPE,
					AppConstants.ErrorCodes.EMAIL_CAN_NOT_UPDATE_ERROR_CODE,
					AppConstants.ErrorMessages.EMAIL_CAN_NOT_UPDATE_ERROR_MESSAGE);
		}

		/** save userEntity i.e. an object of UserEntity */
		UserEntity updatedUserEntity = usersContactDao.saveUserEntity(userEntity);

		/** create and prepare Object of UpdateUserContactResponse */
		UpdateUserContactResponse updateUserContactResponse = new UpdateUserContactResponse();
		updateUserContactResponse.setId(updatedUserEntity.getId());
		updateUserContactResponse.setFirstName(updatedUserEntity.getFirstName());
		updateUserContactResponse.setLastName(updatedUserEntity.getLastName());
		updateUserContactResponse.setPhoneCountryCode(updatedUserEntity.getPhoneCountryCode());
		updateUserContactResponse.setPhoneNumber(updatedUserEntity.getPhoneNumber());
		updateUserContactResponse.setEmail(updatedUserEntity.getEmail());

		/** returning an object of UpdateUserContactResponse.java class */
		return updateUserContactResponse;
	}

	@Override
	public AllUsersContactDetailsResponse getAllUsersContactDetailsByFilters(int page, int limit,
			GetAllUsersContactDetailsBo getUsersDetailsBo) {
		/**
		 * If page is greater than 0 then reduce by one because counting of page starts
		 * from 0
		 */
		if (page > 0)
			page = page - 1;

		/**
		 * Prepare an Object of PageRequest Class using page and limit and keep it in an
		 * reference variable of interface Pageable, just for loose coupling
		 */
		Pageable pageableRequest = PageRequest.of(page, limit);

		Page<UserEntity> userEntityPages = null;
		List<UserEntity> userEntityList = null;

		if (getUsersDetailsBo.getFirstName() == null && getUsersDetailsBo.getLastName() == null
				&& getUsersDetailsBo.getEmail() == null)
			/**
			 * fetch pages by default i.e. findAll but in Ascending Order(As given in query
			 * to fetch data)
			 */
			userEntityPages = usersContactDao
					.allUsersContactDetailsPagesInAscendingOrderOfIdByDefaultValues(pageableRequest);

		/**
		 * when firstName, lastName and email all are something
		 */
		else if (getUsersDetailsBo.getFirstName() != null && getUsersDetailsBo.getLastName() != null
				&& getUsersDetailsBo.getEmail() != null)
			userEntityPages = usersContactDao.getAllUsersContactDetailsByFirstNameAndByLastNameAndEmail(pageableRequest,
					getUsersDetailsBo.getFirstName(), getUsersDetailsBo.getLastName(), getUsersDetailsBo.getEmail());

		/**
		 * when any two out of three i.e. firstName, lastName and email is given
		 */
		else if ((getUsersDetailsBo.getFirstName() != null && getUsersDetailsBo.getLastName() != null
				&& getUsersDetailsBo.getEmail() == null)
				|| (getUsersDetailsBo.getFirstName() == null && getUsersDetailsBo.getLastName() != null
						&& getUsersDetailsBo.getEmail() != null)
				|| (getUsersDetailsBo.getFirstName() != null && getUsersDetailsBo.getLastName() == null
						&& getUsersDetailsBo.getEmail() != null))
			userEntityPages = usersContactDao.getAllUsersContactDetailsByAnyTwoOutOfFirstNameAndByLastNameAndEmail(
					pageableRequest, getUsersDetailsBo.getFirstName(), getUsersDetailsBo.getLastName(),
					getUsersDetailsBo.getEmail());

		/**
		 * when any one out of three i.e. firstName, lastName and email is given
		 */
		else
			userEntityPages = usersContactDao.getAllUsersContactDetailsByFirstNameOrByLastNameOrEmail(pageableRequest,
					getUsersDetailsBo.getFirstName(), getUsersDetailsBo.getLastName(), getUsersDetailsBo.getEmail());

		userEntityList = userEntityPages.getContent();

		/** create object of AllUsersContactDetailsResponse */
		AllUsersContactDetailsResponse allUsersContactDetailsResponse = new AllUsersContactDetailsResponse();
		allUsersContactDetailsResponse.setUserEntities(userEntityList);

		/** create object of CommonPaginationResponse */
		CommonPaginationResponse commonPaginationResponse = new CommonPaginationResponse();
		commonPaginationResponse.setNumberOfElements(userEntityPages.getNumberOfElements());
		commonPaginationResponse.setTotalNumberOfPagesAsPerGivenPageLimit(userEntityPages.getTotalPages());
		allUsersContactDetailsResponse.setCommonPaginationResponse(commonPaginationResponse);

		return allUsersContactDetailsResponse;
	}

	@Override
	public DeleteUserDetailsResponse deleteAnyUserDetails(Long id) {
		/**
		 * Find UserEntity by Id And Throw an Excetion EntityNotFoundException, when
		 * there is no such entity present
		 */
		UserEntity userEntity = usersContactDao.findUserEntityById(id);
		
		DeleteUserDetailsResponse response = new DeleteUserDetailsResponse();
		if(usersContactDao.deleteAnyUserDetailsById(userEntity)==true) {
			response.setMessage(AppConstants.Commons.DELETE_MESSAGE);
		}
		return response;
	}

}
