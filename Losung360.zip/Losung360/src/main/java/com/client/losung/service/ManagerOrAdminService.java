package com.client.losung.service;

import com.client.losung.bo.ManagerOrAdminSignInRequestBo;
import com.client.losung.bo.ManagerOrAdminSignUpRequestBo;
import com.client.losung.enums.RoleType;
import com.client.losung.response.AccountCreatedSuccessfullyResponse;
import com.client.losung.response.ManagerOrAdminSignInResponse;

public interface ManagerOrAdminService {

	AccountCreatedSuccessfullyResponse addmanagerOrAdmin(ManagerOrAdminSignUpRequestBo signUpBo, RoleType roleType);

	ManagerOrAdminSignInResponse sighIn(ManagerOrAdminSignInRequestBo signInBo);

}
