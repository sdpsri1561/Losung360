package com.client.losung.bo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ManagerOrAdminSignUpRequestBo {

	private String fullName;
	private String email;
	private String password;
}
