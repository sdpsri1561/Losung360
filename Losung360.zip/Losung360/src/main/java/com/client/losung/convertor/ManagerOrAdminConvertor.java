package com.client.losung.convertor;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;

import com.client.losung.bo.ManagerOrAdminSignInRequestBo;
import com.client.losung.bo.ManagerOrAdminSignUpRequestBo;
import com.client.losung.entity.ManagerOrAdminEntity;
import com.client.losung.request.ManagerOrAdminSignInRequest;
import com.client.losung.request.ManagerOrAdminSignUpRequest;

public class ManagerOrAdminConvertor {

	public static ManagerOrAdminSignUpRequestBo convertManagerOrAdminRequestToBo(
			@Valid ManagerOrAdminSignUpRequest managerOrAdminSignUpRequest) {
		ManagerOrAdminSignUpRequestBo signUpBo = new ManagerOrAdminSignUpRequestBo();
		BeanUtils.copyProperties(managerOrAdminSignUpRequest, signUpBo);
		return signUpBo;
	}

	public static ManagerOrAdminEntity convertBoToEntity(ManagerOrAdminSignUpRequestBo signUpBo) {
		ManagerOrAdminEntity managerOrAdminEntity = new ManagerOrAdminEntity();
		managerOrAdminEntity.setEmail(signUpBo.getEmail());
		managerOrAdminEntity.setFullName(signUpBo.getFullName());
		managerOrAdminEntity.setPassword(signUpBo.getPassword());
		return managerOrAdminEntity;
	}

	public static ManagerOrAdminSignInRequestBo convertManagerOrAdminLogInRequestToBo(
			@Valid ManagerOrAdminSignInRequest managerOrAdminSignInRequest) {
		ManagerOrAdminSignInRequestBo signInBo = new ManagerOrAdminSignInRequestBo();
		BeanUtils.copyProperties(managerOrAdminSignInRequest, signInBo);
		return signInBo;
	}

}
